package classes;


import javax.swing.*;

import org.w3c.dom.events.MouseEvent;

import java.awt.*;
import java.awt.event.*;

public class Homepage extends JFrame implements ActionListener{

    JLabel l1;
	   
	JButton b1,b2;
	   
	JPanel P1;

	ImageIcon icon;
	

    public Homepage ()
    {
                this.setTitle("Movie Ticket Booking Management System");
        this.setSize(750, 500);
        setLocationRelativeTo(null);
        setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // icon
        icon = new ImageIcon(getClass().getResource("/image/icon.png"));
        this.setIconImage(icon.getImage());


    // panel
        P1 = new JPanel();
        P1.setBounds(0,0,750,500);
        P1.setLayout(null);
		
		JLabel label1 = new JLabel();
        label1.setText("Movie Time");
        label1.setBounds(460, 75, 600, 70);
        label1.setFont(new Font("Serif", Font.BOLD, 30));
        label1.setForeground(Color.decode("#FF7F50"));
        P1.add(label1);

        JLabel label2 = new JLabel();
        label2.setText("Book Movie Ticket");
        label2.setBounds(420, 143, 500, 60);
        label2.setFont(new Font("Serif", Font.BOLD, 30));
        P1.add(label2);


    //button
	   b1 = new JButton("Exit");
	   b1.setFont(new Font("Serif",Font.BOLD,23));
	   b1.setForeground(Color.white);
	   b1.setBackground( Color.red);
	   b1.setBorder(null);
	   b1.setBounds(25,400,88,36);
	   b1.addActionListener(this);
	   b1.setFocusable(false);
	   b1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	   P1.add(b1);


	   b2 =  new JButton ("Get started");
	   b2.setFont(new Font("Serif",Font.BOLD,23));
	   b2.setForeground(Color.white);
	   b2.setBackground(new Color(102,140,208));
	   b2.setBounds(450,390,220,40);
	   b2.addActionListener(this); 
	   b2.setFocusable(false);
	   b2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	   P1.add(b2);



    //image
	   ImageIcon background1 = new ImageIcon(getClass().getResource("/image/background1.jpg"));
        Image img = background1.getImage().getScaledInstance(750, 500, Image.SCALE_DEFAULT);
        ImageIcon background2 = new ImageIcon(img);
        JLabel imgLabel1 = new JLabel(background2);
        imgLabel1.setBounds(0, 0, 750, 500);
        P1.add(imgLabel1);


       this.add(P1);
       setVisible(true);
 

    }


	public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==b1)
		{
			this.dispose();
		}

		else if(ae.getSource()==b2)
		{
			Login r = new Login();
			this.setVisible(false);
		    r.setVisible(true);
		}
	}
	  
}