package classes;


line1 = Files.readAllLines(Paths.get("data\\login data.txt")).get(0);