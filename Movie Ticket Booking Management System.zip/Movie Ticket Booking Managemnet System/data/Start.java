import classes.*;

public class start{
	public static void main(String [] args)
	{
		Start h = new Start();

	}

	
}

