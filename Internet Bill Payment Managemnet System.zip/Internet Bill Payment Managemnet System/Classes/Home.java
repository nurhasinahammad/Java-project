package Classes;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.nio.file.*;

public class Home extends JFrame {
	
    private Container c;
    private ImageIcon icon, logo, background1, background2;
    private JLabel imgLabel1, imgLabel2, tlabel;
	private Image img;	
    private Font f1, f2, f3, f4, f5; 
	private JTextField tf;
    private JPasswordField pf;
	private Cursor cursor;
    private JButton btn1, btn2, btn3, btn4, btn5, nBtn;

    public Home() {
		// Frame Layout
		this.setTitle("Internet Bill Payment Management System");
		this.setSize(900, 600);
		this.setLocationRelativeTo(null);
        this.setResizable(false);		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		c = this.getContentPane();
		c.setLayout(null);
		
		// icon
        icon = new ImageIcon(getClass().getResource("/Images/icon.png"));
        this.setIconImage(icon.getImage());

	    // logo
        logo  = new ImageIcon(getClass().getResource("/Images/login.png"));
        imgLabel1 = new JLabel(logo);
        imgLabel1.setBounds(518, 157, logo.getIconWidth(), logo.getIconHeight());
        c.add(imgLabel1);
		
        // Fonts
		f1 = new Font("Tahoma", Font.BOLD, 35);
        f2 = new Font("Monospaced Bold", Font.BOLD, 30);
		f3 = new Font("Segoe UI", Font.PLAIN, 27);
		f4 = new Font("Segoe UI", Font.PLAIN, 22);
        f5 = new Font("Segoe UI Black", Font.PLAIN, 22);	

        // Titles
        tlabel = new JLabel();
        tlabel.setText("Pay The Internet Bill.....");
        tlabel.setBounds(70, 2, 600, 70);
        tlabel.setFont(f1);
		tlabel.setForeground(Color.decode("#7CA2B9"));
        c.add(tlabel);

        tlabel = new JLabel();
        tlabel.setText("Safely, Securely & Anytime!");
        tlabel.setBounds(330, 40, 600, 70);
        tlabel.setFont(f1);
		tlabel.setForeground(Color.decode("#7CA2B9"));
        c.add(tlabel);	
		
        tlabel = new JLabel();
        tlabel.setText("User Login");
        tlabel.setBounds(350, 145, 500, 60);
        tlabel.setFont(f2);
        c.add(tlabel);

        // Username
        tlabel = new JLabel();
        tlabel.setText("Username");
        tlabel.setBounds(285, 199, 500, 50);
        tlabel.setFont(f3);
        c.add(tlabel);

        tf = new JTextField();
        tf.setBounds(425, 212, 200, 30);
        tf.setFont(f4);
        c.add(tf);

        // Password
        tlabel = new JLabel();
        tlabel.setText("Password");
        tlabel.setBounds(285, 247, 500, 50);
        tlabel.setFont(f3);
        c.add(tlabel);

        pf = new JPasswordField();
        pf.setBounds(425, 260, 200, 30);
        pf.setFont(f5);
        pf.setEchoChar('*');
        c.add(pf);

        // Cursor for JButtons
        cursor = new Cursor(Cursor.HAND_CURSOR);

        // JButtons
        btn1 = new JButton("Login");
        btn1.setBounds(288, 310, 135, 38);
        btn1.setFont(f5);
        btn1.setCursor(cursor);
        btn1.setForeground(Color.WHITE);
        btn1.setBackground(Color.decode("#9EB8AC"));
        c.add(btn1);

        btn2 = new JButton("Sign up");
        btn2.setBounds(488, 310, 135, 38);
        btn2.setFont(f5);
        btn2.setCursor(cursor);
        btn2.setForeground(Color.WHITE);
        btn2.setBackground(Color.decode("#9EB8AC"));
        c.add(btn2);

        btn3 = new JButton("Exit");
        btn3.setBounds(387, 362, 135, 38);
        btn3.setFont(f5);
        btn3.setCursor(cursor);
        btn3.setForeground(Color.WHITE);
        btn3.setBackground(Color.decode("#EC8268"));
        c.add(btn3);

        btn4 = new JButton("About Us");
        btn4.setBounds(31, 508, 190, 40);
        btn4.setFont(f5);
        btn4.setCursor(cursor);
        btn4.setForeground(Color.WHITE);
        btn4.setBackground(Color.decode("#7CA2B9"));
        c.add(btn4);

        btn5 = new JButton("Admin Login");
        btn5.setBounds(667, 508, 190, 40);
        btn5.setFont(f5);
        btn5.setCursor(cursor);
        btn5.setForeground(Color.WHITE);
        btn5.setBackground(Color.decode("#7CA2B9"));
        c.add(btn5);		
        
        nBtn = new JButton("");
        nBtn.setBounds(0, 0, 0, 0);
        c.add(nBtn);
		
		// Action Listener for JButtons
		// Login Button
        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                String textField1 = tf.getText().toLowerCase(); // Username 
                String textField2 = pf.getText(); // Password

                if (textField1.isEmpty() || textField2.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
                            JOptionPane.WARNING_MESSAGE);
                } else {

                    try {
                        String userNameS = "User Name : " + textField1;
                        String passwordS = "Password : " + textField2;
                        BufferedReader reader = new BufferedReader(new FileReader(".\\Data\\user_data.txt"));

                        int totalLines = 0;
                        while (reader.readLine() != null)
                            totalLines++;
                        reader.close();

                        for (int i = 0; i <= totalLines; i++) {
                            String line = Files.readAllLines(Paths.get(".\\Data\\user_data.txt")).get(i);
                            if (line.equals(userNameS)) {
                                String line2 = Files.readAllLines(Paths.get(".\\Data\\user_data.txt")).get((i + 1));
                                if (line2.equals(passwordS)) {
                                    JOptionPane.showMessageDialog(null, "Login Successful.", "Internet Bill Payment Management System",
                                            JOptionPane.WARNING_MESSAGE);

                                    setVisible(false);
                                    User frame = new User();
                                    frame.setVisible(true);
                                    break;
                                }
                            }
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Invalid User Name or Password!", "Warning!",
                                JOptionPane.WARNING_MESSAGE);
                    }

                }

            }
        });
		
		// Sign Up Button
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                SignUp frame = new SignUp();
                frame.setVisible(true);
                setVisible(false);
            }
        });
		
		// Exit Button
        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                System.exit(0);
            }
        });

        // About Us Button
        btn4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                AboutUs frame = new AboutUs();
                frame.setVisible(true);
            }
        });

        // Admin Login
        btn5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                AdminLogin frame = new AdminLogin();
                frame.setVisible(true);
                JOptionPane.showMessageDialog(null, "By default, Admin Name and Password is : 'admin'", "Information!",
                                JOptionPane.INFORMATION_MESSAGE);
            }
        });       

		// background image
        background1 = new ImageIcon(getClass().getResource("/Images/background.jpg"));
		img = background1.getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
		background2 = new ImageIcon(img);
		imgLabel2 = new JLabel(background2);
		imgLabel2.setBounds(0, 0, 900, 600);
		c.add(imgLabel2);		
	}	
	    public static void main(String[] args) {
        Home frame = new Home();
        frame.setVisible(true);
    }
}