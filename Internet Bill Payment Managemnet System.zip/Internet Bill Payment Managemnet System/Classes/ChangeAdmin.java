package Classes;

import java.lang.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.nio.file.*;

public class ChangeAdmin extends JFrame {

    private Container c;
    private ImageIcon icon, background1, background2;
    private JLabel imgLabel2, label1;
	private Image img;
    private Font f1, f2, f3, f4;
    private JTextField tf1;
    private JButton btn1, btn2, btn3, nBtn;
    private JPasswordField tf2;
    private Cursor cursor;

    ChangeAdmin() {
        // Frame Layout
        this.setTitle("Internet Bill Payment Management System");
        this.setSize(900, 600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
        c = this.getContentPane();
        c.setLayout(null);

        // Icon
        icon = new ImageIcon(getClass().getResource("/Images/icon.png"));
        this.setIconImage(icon.getImage());

        // Fonts
        f1 = new Font("Monospaced Bold", Font.BOLD, 30);
        f2 = new Font("Segoe UI Black", Font.PLAIN, 22);
        f3 = new Font("Segoe UI", Font.PLAIN, 27);
        f4 = new Font("Segoe UI", Font.PLAIN, 22);

        // Title
        label1 = new JLabel();
        label1.setText("Change Admin");
        label1.setBounds(337, 30, 500, 60);
        label1.setFont(f1);
        c.add(label1);

        // Admin Name
        label1 = new JLabel();
        label1.setText("Name");
        label1.setBounds(270, 98, 500, 50);
        label1.setFont(f3);
        c.add(label1);

        tf1 = new JTextField();
        tf1.setBounds(410, 110, 200, 30);
        tf1.setFont(f4);
        c.add(tf1);

        // Password
        label1 = new JLabel();
        label1.setText("Password");
        label1.setBounds(267, 149, 500, 50);
        label1.setFont(f3);
        c.add(label1);

        tf2 = new JPasswordField();
        tf2.setBounds(410, 160, 200, 30);
        tf2.setFont(f2);
        tf2.setEchoChar('*');
        c.add(tf2);

        // Cursor for JButtons
        cursor = new Cursor(Cursor.HAND_CURSOR);

        // JButtons
		btn1 = new JButton("Change");
        btn1.setBounds(378, 209, 135, 38);
        btn1.setFont(f2);
        btn1.setCursor(cursor);
        btn1.setForeground(Color.WHITE);
        btn1.setBackground(Color.decode("#9EB8AC"));
        c.add(btn1);

        btn2 = new JButton("Back");
        btn2.setBounds(31, 508, 135, 40);
        btn2.setFont(f2);
        btn2.setCursor(cursor);
        btn2.setForeground(Color.WHITE);
        btn2.setBackground(Color.decode("#807F7E"));
        c.add(btn2);

        btn3 = new JButton("Exit");
        btn3.setBounds(722, 508, 135, 40);
        btn3.setFont(f2);
        btn3.setCursor(cursor);
        btn3.setForeground(Color.WHITE);
        btn3.setBackground(Color.decode("#EC8268"));
        c.add(btn3);

        nBtn = new JButton("");
        nBtn.setBounds(0, 0, 0, 0);
        c.add(nBtn);

        // Change Button
        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                String textField1 = tf1.getText().toLowerCase(); // Username
                String textField2 = tf2.getText(); // Password

                if (textField1.isEmpty() || textField2.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
                            JOptionPane.WARNING_MESSAGE);
                } else {

                    String adminFile = ".\\Data\\admin_data.txt";
                    File oldFile = new File(adminFile);
                    oldFile.delete();
                    File dump = new File(adminFile);

                    try {

                        FileWriter fw = new FileWriter(adminFile, true);
                        BufferedWriter bw = new BufferedWriter(fw);
                        PrintWriter pw = new PrintWriter(bw);

                        pw.println("==========================================");
                        pw.println("=== ###  Travel Agency Admin Data  ### ===");
                        pw.println("==========================================");
                        pw.println("Name : " + textField1);
                        pw.println("Password : " + textField2);
                        pw.println("==========================================");

                        pw.flush();
                        pw.close();
                        bw.close();
                        fw.close();

                        JOptionPane.showMessageDialog(null, "Admin Name and Password has been changed.",
                                "Admin Passowrd", JOptionPane.INFORMATION_MESSAGE);
                        setVisible(false);

                    } catch (Exception ex) {
                        System.out.print(ex);
                    }

                }

            }
        });
		
		// Back Button
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                setVisible(false);
                Admin frame = new Admin();
                frame.setVisible(true);
            }
        });
		
		// Exit Button
        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                System.exit(0);
            }
        });
		
		// background image
        background1 = new ImageIcon(getClass().getResource("/Images/background.jpg"));
		img = background1.getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
		background2 = new ImageIcon(img);
		imgLabel2 = new JLabel(background2);
		imgLabel2.setBounds(0, 0, 900, 600);
		c.add(imgLabel2);    
	}
	
    public static void main(String[] args) {

        ChangeAdmin frame = new ChangeAdmin();
        frame.setVisible(true);
    }
}