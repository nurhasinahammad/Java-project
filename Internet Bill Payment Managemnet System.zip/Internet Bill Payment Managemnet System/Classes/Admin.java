package Classes;

import java.lang.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Admin extends JFrame {

    private Container c;
    private ImageIcon icon, logo, background1, background2;
    private JLabel imgLabel1, imgLabel2, label1;
	private Image img;
    private Font f1, f2, f3, f4;
	private JComboBox combobox;
    private JButton btn1, btn2, btn3, nBtn;
    private Cursor cursor;
	
    Admin() {
	
		// Frame Layout
		this.setTitle("Internet Bill Payment Management System");
		this.setSize(900, 600);
		this.setLocationRelativeTo(null);
        this.setResizable(false);		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		c = this.getContentPane();
		c.setLayout(null);
		
		// icon
        icon = new ImageIcon(getClass().getResource("/Images/icon.png"));
        this.setIconImage(icon.getImage());

	    // logo
        logo  = new ImageIcon(getClass().getResource("/Images/admin2.png"));
        imgLabel1 = new JLabel(logo);
        imgLabel1.setBounds(523, 42, logo.getIconWidth(), logo.getIconHeight());
        c.add(imgLabel1);
		
		// Fonts
        f1 = new Font("Monospaced Bold", Font.BOLD, 30);
        f2 = new Font("Segoe UI Black", Font.PLAIN, 22);
        f3 = new Font("Segoe UI", Font.PLAIN, 27);
		f4 = new Font("Segoe UI", Font.PLAIN, 22);
		
        // Title
        label1 = new JLabel();
        label1.setText("Admin Panel");
        label1.setBounds(330, 30, 500, 60);
        label1.setFont(f1);
        c.add(label1);
		
		// Information
        label1 = new JLabel();
        label1.setText("Information");
        label1.setBounds(297, 100, 500, 50);
        label1.setFont(f3);
        c.add(label1);

        // Cursor for JButtons
        cursor = new Cursor(Cursor.HAND_CURSOR);       

	    // JComboBox
		combobox = new JComboBox();
		combobox.addItem("User");
		combobox.addItem("Bill");
		combobox.setBounds(460, 108, 131, 34);
        combobox.setFont(f4);
		combobox.setCursor(cursor);
		c.add(combobox);

        // JButtons		
		btn1 = new JButton("Change Admin");
        btn1.setBounds(343, 375, 200, 38);
        btn1.setFont(f2);
        btn1.setCursor(cursor);
        btn1.setForeground(Color.WHITE);
        btn1.setBackground(Color.decode("#9EB8AC"));
        c.add(btn1);

        btn2 = new JButton("Back");
        btn2.setBounds(31, 508, 135, 40);
        btn2.setFont(f2);
        btn2.setCursor(cursor);
        btn2.setForeground(Color.WHITE);
        btn2.setBackground(Color.decode("#807F7E"));
        c.add(btn2);
		
        btn3 = new JButton("Exit");
        btn3.setBounds(722, 508, 135, 40);
        btn3.setFont(f2);
        btn3.setCursor(cursor);
        btn3.setForeground(Color.WHITE);
        btn3.setBackground(Color.decode("#EC8268"));
        c.add(btn3);
        
        nBtn = new JButton("");
        nBtn.setBounds(0, 0, 0, 0);
        c.add(nBtn);

        // User & Bill Information 
        combobox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				String selectedOption = (String) combobox.getSelectedItem();
				
				if ("User".equals(selectedOption)) {
					setVisible(false);
					UserInformation frame = new UserInformation();
					frame.setVisible(true);
					} else if ("Bill".equals(selectedOption)) {
						setVisible(false);
						BillInformation frame = new BillInformation();
						frame.setVisible(true);
					}
			    }
	    	});

        // Change Admin
        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                ChangeAdmin frame = new ChangeAdmin();
                frame.setVisible(true);
            }
        }); 		
		
        // Back
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                
                setVisible(false);
                Home frame = new Home();
                frame.setVisible(true);
            }
        });
		
		// Exit Button
        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                System.exit(0);
            }
        });

		// background image
        background1 = new ImageIcon(getClass().getResource("/Images/background.jpg"));
		img = background1.getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
		background2 = new ImageIcon(img);
		imgLabel2 = new JLabel(background2);
		imgLabel2.setBounds(0, 0, 900, 600);
		c.add(imgLabel2);	
	}

    public static void main(String[] args) {

        Admin frame = new Admin();
        frame.setVisible(true);
    }
}		