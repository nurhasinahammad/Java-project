package Classes;

import java.lang.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.*;

public class SignUp extends JFrame {

    private Container c;
    private ImageIcon icon, logo, background1, background2;
    private JLabel imgLabel1, imgLabel2, label1;
	private Image img;
    private Font f1, f2, f3, f4;
    private JTextField tf1, tf2, tf3, tf4, tf5, tf6;
    private JPasswordField pf1, pf2;
    private Cursor cursor;
	private JButton btn1, btn2, btn3, btn4, nBtn;
    private int a, b;
    
	SignUp() {
		// Frame Layout
		this.setTitle("Internet Bill Payment Management System");
		this.setSize(900, 600);
		this.setLocationRelativeTo(null);
        this.setResizable(false);		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		c = this.getContentPane();
		c.setLayout(null);
		
		// icon
        icon = new ImageIcon(getClass().getResource("/Images/icon.png"));
        this.setIconImage(icon.getImage());

	    // logo
        logo  = new ImageIcon(getClass().getResource("/Images/signup.png"));
        imgLabel1 = new JLabel(logo);
        imgLabel1.setBounds(584, 31, logo.getIconWidth(), logo.getIconHeight());
        c.add(imgLabel1);

        // Fonts
        f1 = new Font("Monospaced Bold", Font.BOLD, 30);
        f2 = new Font("Segoe UI Black", Font.PLAIN, 22);
        f3 = new Font("Segoe UI", Font.PLAIN, 27);
        f4 = new Font("Segoe UI", Font.PLAIN, 22);

        // Title
        label1 = new JLabel();
        label1.setText("Create User Account");
        label1.setBounds(278, 17, 500, 60);
        label1.setFont(f1);
        c.add(label1);

        // Username
        label1 = new JLabel();
        label1.setText("Username");
        label1.setBounds(203, 71, 500, 50);
        label1.setFont(f3);
        c.add(label1);

        tf1 = new JTextField();
        tf1.setBounds(432, 84, 260, 30);
        tf1.setFont(f4);
        c.add(tf1);

        // Bill ID
        label1 = new JLabel();
        label1.setText("Bill ID");
        label1.setBounds(203, 117, 500, 50);
        label1.setFont(f3);
        c.add(label1);

        tf2 = new JTextField();
        tf2.setBounds(432, 130, 260, 30);
        tf2.setFont(f4);
        c.add(tf2);

        // Address
        label1 = new JLabel();
        label1.setText("Address");
        label1.setBounds(203, 165, 500, 50);
        label1.setFont(f3);
        c.add(label1);

        tf3 = new JTextField();
        tf3.setBounds(432, 178, 260, 30);
        tf3.setFont(f4);
        c.add(tf3);

        //Contact No 
        label1 = new JLabel();
        label1.setText("Contact No");
        label1.setBounds(203, 213, 500, 50);
        label1.setFont(f3);
        c.add(label1);

        tf4 = new JTextField();
        tf4.setBounds(432, 226, 260, 30);
        tf4.setFont(f4);
        c.add(tf4);

        // Email
        label1 = new JLabel();
        label1.setText("Email");
        label1.setBounds(203, 261, 500, 50);
        label1.setFont(f3);
        c.add(label1);

        tf5 = new JTextField();
        tf5.setBounds(432, 274, 260, 30);
        tf5.setFont(f4);
        c.add(tf5);

        // Password
        label1 = new JLabel();
        label1.setText("Password");
        label1.setBounds(203, 309, 500, 50);
        label1.setFont(f3);
        c.add(label1);

        pf1 = new JPasswordField();
        pf1.setBounds(432, 322, 260, 30);
        pf1.setFont(f2);
        pf1.setEchoChar('*');
        c.add(pf1);
		
        // Confirm Password		
        label1 = new JLabel();
        label1.setText("Confirm Password");
        label1.setBounds(203, 357, 500, 50);
        label1.setFont(f3);
        c.add(label1);

        pf2 = new JPasswordField();
        pf2.setBounds(432, 370, 260, 30);
        pf2.setFont(f2);
        pf2.setEchoChar('*');
        c.add(pf2);		

        // Captcha Label and Text Field
        label1 = new JLabel();
        label1.setText("Captcha");
        label1.setBounds(203, 405, 500, 50);
        label1.setFont(f3);
        c.add(label1);

        tf6 = new JTextField();
        tf6.setBounds(432, 418, 260, 30);
        tf6.setFont(f4);
        c.add(tf6);

        // To get a random number for captcha
        Random rand = new Random();
        int a = rand.nextInt(10);
        int b = rand.nextInt(10);

        // Captcha
        label1 = new JLabel();
        label1.setText(" " + a + " + " + b + " ");
        label1.setBounds(315, 418, 80, 30);
        label1.setFont(f3);
        label1.setForeground(Color.red);
        label1.setBackground(Color.decode("#FFD3D3"));
        label1.setOpaque(true);
        c.add(label1);

        // Cursor for JButtons
        cursor = new Cursor(Cursor.HAND_CURSOR);

        // JButtons
        btn1 = new JButton("Reset");
        btn1.setBounds(285, 461, 135, 38);
        btn1.setFont(f2);
        btn1.setCursor(cursor);
        btn1.setForeground(Color.WHITE);
        btn1.setBackground(Color.decode("#9EB8AC"));
        c.add(btn1);

        btn2 = new JButton("Sign Up");
        btn2.setBounds(484, 461, 135, 38);
        btn2.setFont(f2);
        btn2.setCursor(cursor);
        btn2.setForeground(Color.WHITE);
        btn2.setBackground(Color.decode("#9EB8AC"));
        c.add(btn2);

        btn3 = new JButton("Back");
        btn3.setBounds(31, 508, 135, 40);
        btn3.setFont(f2);
        btn3.setCursor(cursor);
        btn3.setForeground(Color.WHITE);
        btn3.setBackground(Color.decode("#807F7E"));
        c.add(btn3);

        btn4 = new JButton("Exit");
        btn4.setBounds(722, 508, 135, 40);
        btn4.setFont(f2);
        btn4.setCursor(cursor);
        btn4.setForeground(Color.WHITE);
        btn4.setBackground(Color.decode("#EC8268"));
        c.add(btn4);

        nBtn = new JButton("");
        nBtn.setBounds(0, 0, 0, 0);
        c.add(nBtn);

        // Reset Button
        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                setVisible(false);
                SignUp frame = new SignUp();
                frame.setVisible(true);
            }
        }); 

        // Sign up Button
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                String textField1 = tf1.getText().toLowerCase(); // Username
                String textField2 = tf2.getText(); // Bill ID
                String textField3 = pf1.getText(); // Password
                String textField4 = pf2.getText(); // Confirm Password 
				String textField5 = tf3.getText(); // Address
				String textField6 = tf4.getText(); // Contact No
				String textField7 = tf5.getText(); // Email
                String textField8 = tf6.getText(); // Captcha
                int result = 0;

                if (textField8.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
                            JOptionPane.WARNING_MESSAGE);
                } else {
                    result = Integer.parseInt(tf6.getText());
                    if (textField1.isEmpty() || textField2.isEmpty() || textField3.isEmpty() || textField4.isEmpty()
                            || textField5.isEmpty() || textField6.isEmpty() || textField7.isEmpty() || textField8.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
                                JOptionPane.WARNING_MESSAGE);
                    } else if (result != (a + b)) {
						JOptionPane.showMessageDialog(null, "Wrong Captcha.", "Warning!",
						JOptionPane.WARNING_MESSAGE);
                    } else if (!textField3.equals(textField4)) {
						JOptionPane.showMessageDialog(null, "Password and Confirm Password do not match.", "Warning!",
                        JOptionPane.WARNING_MESSAGE);
						} else {

                        try {
                            File file = new File(".\\Data\\user_data.txt");
                            if (!file.exists()) {
                                file.createNewFile();
                            }
                            FileWriter fw = new FileWriter(file, true);
                            BufferedWriter bw = new BufferedWriter(fw);
                            PrintWriter pw = new PrintWriter(bw);

                            LocalDateTime myDateObj = LocalDateTime.now();
                            DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("HH:mm a, dd/MM/yyyy");

                            String timeAndDate = myDateObj.format(myFormatObj);

                            pw.println("Username : " + textField1);
                            pw.println("Password : " + textField3);
                            pw.println("Email : " + textField2);
                            pw.println("Address : " + textField5);
                            pw.println("Contact No : " + textField6);
                            pw.println("Time & Date : " + timeAndDate);
                            pw.println("===============================================");
                            pw.close();

                        } catch (Exception ex) {
                            System.out.print(ex);
                        }

                        JOptionPane.showMessageDialog(null, "Registration Successfully Completed.",
                                "Registration Complete", JOptionPane.WARNING_MESSAGE);
                        setVisible(false);
                        Home frame = new Home();
                        frame.setVisible(true);
                    }
                }
            }
        });
		
        // Back Button
        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                setVisible(false);
                Home frame = new Home();
                frame.setVisible(true);
            }
        });	

	    // Exit Button
        btn4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                System.exit(0);
            }
        }); 
    
		// background image
        background1 = new ImageIcon(getClass().getResource("/Images/background.jpg"));
		img = background1.getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
		background2 = new ImageIcon(img);
		imgLabel2 = new JLabel(background2);
		imgLabel2.setBounds(0, 0, 900, 600);
		c.add(imgLabel2);	
	}

    public static void main(String[] args) {

        SignUp frame = new SignUp();
        frame.setVisible(true);
    }
}