import Classes.*;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Start {
    public static void main(String[] args) {
        Home frame = new Home();
        frame.setVisible(true);
    }
}
